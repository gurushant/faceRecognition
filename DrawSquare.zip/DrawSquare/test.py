import cv2
import os
img=cv2.imread("data/test.png")
print(img)