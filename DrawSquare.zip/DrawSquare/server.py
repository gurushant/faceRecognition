import os
import flask


from flask import  request

import cv2
import time
import tornado.wsgi
from PIL import Image
import tornado.httpserver
from flask import jsonify
import base64
from flask_cors import CORS
from h5py.h5s import NULL

app = flask.Flask(__name__)
CORS(app, resources={r"/*": {"origins": "*"}})
PORT=8580;


DIRECOTRY="data/"
PATH="http://localhost:8080/drawSquare/data/"
IMAGE_DIRECTORY="images/"
TOMCAT_SERVER_PATH="/Users/gurushant/Desktop/software/apache-tomcat-7.0.77/webapps/drawSquare/data/"
@app.route('/save',methods=['POST'])
def save_image_squares():
    response=NULL;
    if request.method == 'POST':
        req_content_dict=request.get_json(silent=True)
        rec_count=len(req_content_dict)
        print("Length is =>"+str(rec_count))
        j=0
        
        #Create the output file
        file_name = str(int(time.time()))
        try:
            f= open(TOMCAT_SERVER_PATH+file_name+".txt","w+")
        except (IOError) as e:
            errorMessage = '{}: {}'.format(file_name, e)
            print(errorMessage)
            out = {"status":"ERROR","message":"Error occured.Please try again later"}
            return jsonify(out)
            #end of file creation 
                  
        for j in range(rec_count):
            content_dict=req_content_dict[j];
            if content_dict is not None :
                dict_len=len(content_dict);
                print("Length is =>"+str(dict_len))
                
                i=0
        
                for i in range(dict_len):
                    image_name=content_dict[i]["info"]["name"]
                    print("Image name is =>"+str(image_name))
                    rect_dict=content_dict[i]['actualObj']
                    
                    x1=str(rect_dict['x1'])
                    y1=str(rect_dict['y1'])
                    x2=str(rect_dict['x2'])
                    y2=str(rect_dict['y2'])
                    class_name=rect_dict['class']
                    
                    line=image_name+","+ x1+","+y1+","+x2+","+y2+","+class_name
                    print(line)
                    f.write(line+"\n") 
                        
    f.close()
    out = {"status":"SUCCESS","message":"Successfully saved.","data":PATH+file_name+".txt"}
    return jsonify(out)    


@app.after_request
def add_header(r):
    """
    Add headers to both force latest IE rendering engine or Chrome Frame,
    and also to cache the rendered page for 10 minutes.
    """
    r.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    r.headers["Pragma"] = "no-cache"
    r.headers["Expires"] = "0"
    r.headers['Cache-Control'] = 'public, max-age=0'
    return r


@app.route('/get_image_names',methods=['GET'])
def get_image_names():
    img_list=os.listdir("images")
    print(img_list)
    imageNames=[]
    for i in range(len(img_list)):
        _, file_extension = os.path.splitext(IMAGE_DIRECTORY+img_list[i])
        if file_extension in [".jpg",".jpeg",".png"]:
            imageNames.append(img_list[i])
            
    return jsonify(imageNames)


global img_counter
img_counter=0
@app.route('/get_images',methods=['POST'])
def get_images():
    img_list=os.listdir("images")
    global img_counter
    print(img_list)
    imageData=[]
    req_content_dict=request.get_json(silent=True)
    print("Request data is=>");
    print(req_content_dict[0])
     
    for i in range(len(req_content_dict)):
        file_name=req_content_dict[i]
        with open(IMAGE_DIRECTORY+file_name, "rb") as f:
            source=base64.b64encode(f.read())
            data={"data":source,"id":img_counter,"name":file_name}
            imageData.append(data)
            img_counter=img_counter+1
            
    return jsonify(imageData)

@app.route('/get_shape',methods=['GET'])
def get_shape():
    shape="RECTANGLE"
    out={"shape":shape}
    return jsonify(out)



#Serer code            
def start_tornado(app, port=PORT):
    http_server = tornado.httpserver.HTTPServer(
        tornado.wsgi.WSGIContainer(app))
##,ssl_options = { "certfile": "/home/koustubh/catfish.pem"})
    http_server.listen(port)
    print("Tornado server starting on port {}".format(port))
    tornado.ioloop.IOLoop.instance().start()



if __name__ == '__main__':
    #logger.info('Running the main function')
    app.run(host="0.0.0.0", port=int(PORT), debug=True, use_reloader=False,threaded=True)
    #spoof_graph=load_graph('bigvision_spoof_jan3_resnet.pb')  
    start_tornado(app)
        
#end of server code



