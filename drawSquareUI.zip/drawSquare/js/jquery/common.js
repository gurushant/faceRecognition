 $(document).ready(function () {
           $("[name='my-checkbox']").bootstrapSwitch();
      });

