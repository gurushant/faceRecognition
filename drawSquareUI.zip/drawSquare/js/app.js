﻿var app = angular.module('app', ['ngRoute']);

app.config(['$locationProvider', '$routeProvider', function ($locationProvider, $routeProvider) {
        
    $routeProvider.when('/drawSquare', { //Routing for show list of employee
        templateUrl: 'views/square.html',
        controller: 'SquareController'
    })
}]);